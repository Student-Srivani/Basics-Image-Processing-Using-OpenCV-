# Image_Proceesing_Using_OpenCV
It is an open-source library that can be used to perform tasks like face detection, objection tracking, landmark detection, and much more
